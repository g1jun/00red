//
//  ViewController.swift
//  ILWeb
//
//  Created by MAC on 16/5/18.
//  Copyright © 2016年 web. All rights reserved.
//

import UIKit
import JavaScriptCore

@objc protocol JavaScriptMethodProtocol: JSExport {
    var value: String {get set}
    func postContent(value: String, _ number: String)
    func postContent(value: String, number: String)
}

class JavaScriptMethod : NSObject, JavaScriptMethodProtocol {
    
    var value: String {
        get { return ""}
        set {          }
    }
    
    func postContent(value: String, _ number: String) {
        //方法名postContent
    }
    
    func postContent(value: String, number: String) {
        //方法名postContentNumber
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let path = NSBundle.mainBundle().pathForResource("index", ofType: "html")
        let html = try! String(contentsOfFile: path!)
        self.webView.loadHTMLString(html, baseURL: nil)
        
        let jsContext = self.webView.valueForKeyPath("documentView.webView.mainFrame.javaScriptContext") as? JSContext
        jsContext?.setObject(JavaScriptMethod(), forKeyedSubscript: "callSwift")
    }




}

