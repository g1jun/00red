//
//  ILDemoView.swift
//  ILXibDemo
//
//  Created by MAC on 16/7/25.
//  Copyright © 2016年 Team. All rights reserved.
//

import UIKit

class ILDemoView: ILXibView {

    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.label.text = "你好中国"
    }

}
