//
//  ILSwiftCallOCTest.swift
//  ILSwift
//
//  Created by Mac on 15/5/28.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

import UIKit
import XCTest

class ILSwiftCallOCTest: XCTestCase {


    func testCallOC() {
        //如果找不到ILWriteByOC类，检查1.此类是否加入到TestTarget中，2.TestTarget的桥接文件是否设置，路径是否正确
        let oc = ILWriteByOC()
        oc.name = "oc"
    }
    
    func testCompline() {
        let wirteBySwift = ILSwiftBean()
    }



}
