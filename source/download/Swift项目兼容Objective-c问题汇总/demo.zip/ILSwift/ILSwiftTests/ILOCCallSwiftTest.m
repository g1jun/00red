//
//  ILOCCallSwiftTest.m
//  ILSwift
//
//  Created by Mac on 15/5/28.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "ILSwiftTests-Swift.h"



@interface ILOCCallSwiftTest : XCTestCase

@end

@implementation ILOCCallSwiftTest



- (void)testCallSwift
{
    
    ILWriteBySwift *swiftClzz = [ILWriteBySwift newInstance];
    swiftClzz.name = @"name";
}



@end
