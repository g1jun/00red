//
//  ILWriteByOC.m
//  ILSwift
//
//  Created by 一叶 http://00red.com on 15/5/28.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import "ILWriteByOC.h"
@implementation ILWriteByOC

@end
