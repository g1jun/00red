//
//  ILNotFindWriteByOCController.h
//  ILSwift
//
//  Created by Mac on 15/6/2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ILNotFindWriteByOCController : UIViewController

@end
