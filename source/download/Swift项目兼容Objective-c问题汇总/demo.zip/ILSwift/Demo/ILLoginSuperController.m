//
//  ILLoginController.m
//  ILSwift
//
//  Created by Mac on 15/6/2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import "ILLoginSuperController.h"

@interface ILLoginSuperController ()

@end

@implementation ILLoginSuperController


- (IBAction)loginButtonPressed:(id)sender
{
}
@end
