//
//  ILMainTableController.swift
//  ILSwift
//
//  Created by Mac on 15/6/2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

import UIKit

class ILMainTableController: UITableViewController {

    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let coord = (indexPath.section, indexPath.row)
        switch (coord) {
            case (0, 0):
                self.navigationController?.pushViewController(ILXibNotShowController(), animated: true)
            case (0, 1):
                self.navigationController?.pushViewController(ILXibController(), animated: true)
            default:
                break
        }
    }



}
