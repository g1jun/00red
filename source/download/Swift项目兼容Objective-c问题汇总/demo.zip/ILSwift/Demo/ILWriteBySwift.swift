//
//  ILWriteBySwift.swift
//  ILSwift
//
//  Created by 一叶 http://00red.com on 15/5/28.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

import UIKit

enum Direction {
    case South, North
}

@objc(ILWriteBySwift)
class ILWriteBySwift {
    var name: String!
    
    class func newInstance() -> ILWriteBySwift {
        return ILWriteBySwift()
    }
    
    func printDirection(dir: Direction) {
        println("---->\(dir)")
    }
    
}
