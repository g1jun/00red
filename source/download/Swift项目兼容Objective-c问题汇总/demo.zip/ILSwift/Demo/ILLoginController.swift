//
//  ILLoginController.swift
//  ILSwift
//
//  Created by Mac on 15/6/2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

import UIKit

class ILLoginController: ILLoginSuperController {

    override func loginButtonPressed(sender: AnyObject!) {
        ILHTTPRequest.requestLogin(self.userNameField.text, password: self.passwordField.text) { (state) -> (Void) in
            //具体业务逻辑
        }
    }
    
}
