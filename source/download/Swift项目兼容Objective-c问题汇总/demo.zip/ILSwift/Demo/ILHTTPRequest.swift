//
//  ILHTTPRequest.swift
//  ILSwift
//
//  Created by Mac on 15/6/1.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

import UIKit

enum HTTPState: Int {
    case Succed = 0, Failed = 1, NetworkError = 2, ServerError = 3, Others = 4
}

class ILHTTPRequest: NSObject {
   
    class func requestLogin(userName: String, password: String, callback: (state: HTTPState) -> (Void)) {
        dispatch_async(dispatch_get_global_queue(0, 0), { () -> Void in
            NSThread.sleepForTimeInterval(3)
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                callback(state: HTTPState.Succed)
            })
        })
    }
    
    class func wrapRequestLogin(userName: String, password: String, callback: (state: Int) -> (Void)) {
        self.requestLogin(userName, password: password) { (state) -> (Void) in
            callback(state: state.rawValue)
        }
    }
    
}
